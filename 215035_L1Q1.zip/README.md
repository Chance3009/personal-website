# This is Personal Website of Chan Ci En
and
## SSE3308 Web Application Development Individual Project

Nothing interesting here.